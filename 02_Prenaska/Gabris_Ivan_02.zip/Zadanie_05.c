#include <stdio.h>

int main(){
    char Text[100];
    char Text2[100];
    char text3[100];

    /*puts("Zadaj text.");
    scanf("%s", Text);
    puts(Text);*/

    /*puts("Zadaj text2.");
    fgets(Text2, sizeof(Text2), stdin);
    puts(Text2);*/

    //Funkciu gets nespusti(asi gcc), pretoze je to nebezpecne.
    /*puts("Zadaj text3.");
    gets(text3);
    puts(text3);*/

    return 0;

}
