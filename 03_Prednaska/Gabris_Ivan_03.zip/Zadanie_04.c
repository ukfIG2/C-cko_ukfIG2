FILE    -   je to stream typu file. Define v stdio.h.
    typedef struct _IO_FILE FILE;
size_t - reprezentuje velkost objektu. Define v stddef.h.
    typedef __SIZE_TYPE__ size_t;
time_t  -   reprezentuje cas. Define v time_t.h.
    typedef __time_t time_t;
wchar_t - reprezentuje wide character. Define v wchar.h.
    typedef __WCHAR_TYPE__ wchar_t;
fpos_t - reprezentuje cestu k priecinku. Define v stdio.h.
    typedef __fpos_t fpos_t;
